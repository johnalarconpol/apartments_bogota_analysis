# Bogota Apartments ETL

![Bogota Apartments ETL](https://i.ibb.co/DGHmwNv/ETL.png)